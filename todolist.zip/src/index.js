import React from 'react';
import ReactDom from 'react-dom'
import Todolist from './Todolist'
import { Provider } from 'react-redux'
import store from './store/index'


const App = (
    <Provider store={store}>
        {/* Provider 可以让内部的组件使用store */}

        <Todolist></Todolist>
    </Provider>
)

ReactDom.render(App, document.getElementById('root'))




