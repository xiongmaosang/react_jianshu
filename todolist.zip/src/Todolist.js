import React,{ Component,Fragment } from 'react'
import * as actionCreators from './store/actionCreator'
import { connect } from 'react-redux'

class Todolist extends Component{
    constructor(props){
        super(props)
    }

    render() {
        const { inputValue,list,handleInputChange,handleClick,handleDelete } = this.props;
        //结构赋值，我定义一个inputValue的变量，他的值等于this.props.inputValue

        return (
            <Fragment>
                <input
                    onChange={handleInputChange}
                    value={inputValue} type="text"/>
                <button onClick={handleClick}>提交</button>
                <ul>
                    {
                        list.map( (item,index) => {
                            return <li onClick={()=>{handleDelete(index)}} key={index}>{item}</li>
                        })
                    }
                </ul>
            </Fragment>
        )
    }
    componentDidMount() {
       this.props.initData()
    }
}

//组件做连接的规则 让store的数据映射到组件的props上面
const mapStateToProps = (state) => {  //state就是store的数据
    return {
        inputValue:state.inputValue,
        list:state.list
    }
};

//如果想对store的数据做修改通过
//组件做连接的规则 把store的dispatch方法挂载到props上
const mapDispatchToProps = (dispatch)=>{ //dispatch就是store.dispatch()
    return {
        handleInputChange(e){
            const action = actionCreators.getInputChangeAction(e.target.value)
            dispatch(action)
        },

        handleClick(){
            const action = actionCreators.getAddItem();
            dispatch(action)
        },

        handleDelete(index){
            const action = actionCreators.getDeleteItem(index);
            dispatch(action)
        },

        initData(){
            const action = actionCreators.getTodoList();
            dispatch(action)
        }
    }
};
export default connect(mapStateToProps,mapDispatchToProps)(Todolist) // 让Todolist组件和store做连接

