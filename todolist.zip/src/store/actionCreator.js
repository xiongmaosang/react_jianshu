import * as actionTypes from './actionTypes';
import axios from 'axios';

export const getInputChangeAction = (value)=>{
    return {
        type:actionTypes.CHANGE_INPUT_VALUE,
        value:value
    }
};

export const getAddItem = () => {
    return {
        type:actionTypes.ADD_ITEM
    }
};

export const getDeleteItem = (index)=>{
    return {
        type:actionTypes.DELETE_ITEM,
        index
    }
};

export const initListAction = (data)=>{
    return {
        type:actionTypes.INIT_ITEM,
        data
    }
};
export const getTodoList = ()=>{
    return (dispatch) => {  //会自动拿到dispatch方法
        axios.get('/api/todolist').then((res)=>{
            const data = res.data.data;
            console.log(data);
            const action = initListAction(data)
            dispatch(action)
        })
    }
};








